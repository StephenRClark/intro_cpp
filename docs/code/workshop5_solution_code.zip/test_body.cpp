// Exercise 2: Test code for the body class

// To avoid warnings tell the compiler to use a recent standard of C++:
// g++ -std=c++17 vector3d.cpp body.cpp test_body.cpp -o test_body
// ./test_body

#include <iostream>
#include <iomanip>
#include "vector3d.hpp"
#include "body.hpp"

using std::cout, std::endl;

int main()
{
  // Hard-code the data on the bodies given in the exercise:
  double ma = 3.29E23;
  vec ra = vec(5.05E7,-3.04E7,-7.12E6);
  vec va = vec(15.57,43.96,2.16);
  double mb = 3.69E23;
  vec rb = vec(4.70E7,2.26E8,3.57E6);
  vec vb = vec(-22.80,7.01,0.71);

  // Construct two body objects with this data:
  body mercury(ma, ra, va);
  body mars(mb, rb, vb); 
  
  // Perform calculations of required quantities:
  double distance = mercury.distance(mars);
  vec dir = mercury.direction(mars);
  vec L = mercury.angular_momentum(mars);

  // Output results:
  cout << std::setprecision(3);
  cout << "distance = " << distance << " km" << endl; 
  cout << "direction = " << dir << " km" << endl; 
  cout << "L = " << L << " kgkm^2s^-1" << endl;

  return EXIT_SUCCESS; 
}