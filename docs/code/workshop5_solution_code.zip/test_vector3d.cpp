// Exercise 1: Test code for the 3d vector class

// To avoid warnings tell the compiler to use a recent standard of C++:
// g++ -std=c++17 vector3d.cpp test_vector3d.cpp -o test_vector3d
// ./test_vector3d

#include <iostream>
#include "vector3d.hpp"

using std::cout, std::endl;

int main()
{
  vec u; // Test default initialisation to (0,0,0)
  vec r;
  r.set(7,4,-6); // Test setting components
  vec v(2,1,3); // Test initialisation with explicit components
  vec w(2,-2,1);
  vec v_new(v); // Test initialisation using another vector
  vec w_new = w; // Test initialisation via assignment
  
  vec dir = v.normalize(); // Compute the direction dir of v
  double v_len = v.length(); // Compute the length of v
  v_new /= v_len; // Test division of a vector by scalar
  double unit_dot = v_new.dot(dir); // Should be unity
  cout << "TEST: v_new.dir = " << unit_dot << endl;

  dir *= v_len; // Test multiplication by a scalar by making dir = v
  vec z = v - dir; // Test subtraction of vectors - should be zero
  cout << "TEST: z = v - v_len*dir = " << z << endl; // Test vector display insertion

  u = v.cross(w); // Test cross product u = v x w
  // Test the dot product of u with v and w which should both be zero
  cout << "TEST: u.v = " << u.dot(v) << ", u.w = " << u.dot(w) << endl;
  // We defined r as v x w so test r.u which should equal |r|^2 = 101
  cout << "TEST: |r|^2 = " << r.lengthsq() << ", and r.u = " << r.dot(u) << endl;
  double vw_theta = v.angle(w); // Test the computation of the angle between v and w
  cout << "TEST: theta = " << vw_theta << " radians" << endl;
  
  z -= r; // Test subtraction assignment, given z = (0,0,0) should give r.(-z) = 101
  cout << "TEST: r.(-z) = " << r.dot(-z) << endl; // Test vector negation
  z += r; // Test addition assignment
  cout << "TEST: z = " << z << endl;

  vec p = 0.5*v + w*0.25; // Test LHS, RHS scalar multiplication and vector addition 
  double udotp = u.dot(p); // Should be zero since p lies in the plane defined by v and w
  cout << "TEST: u.p = " << udotp << endl;

  return EXIT_SUCCESS; 
}