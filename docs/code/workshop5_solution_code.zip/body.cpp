#include <iostream>
#include <cmath>
#include "vector3d.hpp"
#include "body.hpp"

using std::cout, std::endl;

///////////////////////////
// Implement the body class
///////////////////////////
body::body():
mass_(0), pos_(vec(0,0,0)), vel_(vec(0,0,0)) 
{
}

body::body(const body &b):
mass_(b.mass_), pos_(b.pos_), vel_(b.vel_)
{
}

body::body(double m, vec pos, vec vel):
mass_(m), pos_(pos), vel_(vel)
{	
}

void body::set(double m, vec pos, vec vel)
{
	mass_= m;
	pos_ = pos;
	vel_ = vel;
}

body::body(double m, double x, double y, double z, double vx, double vy, double vz):
mass_(m), pos_(vec(x,y,z)), vel_(vec(vx,vy,vz))
{
}

void body::set(double m, double x, double y, double z, double vx, double vy, double vz)
{
	mass_ = m;
	pos_ = vec(x,y,z);
	vel_ = vec(vx,vy,vz);
}

body &body::operator=(const body &b)
{
	mass_ = b.mass_;
	pos_ = b.pos_;
	vel_ = b.vel_;
	return *this;
}

void body::output(std::ostream &os) const
{
	os << "m = " << mass_ << ", pos = " << pos_ << ", vel = " << vel_;
}

double body::distance(const body &b) const
{
    vec r = pos_ - b.pos_; // Vector connecting the two bodies
    return r.length(); // Return length of vector
}

vec body::direction(const body &b) const
{
    vec r = pos_ - b.pos_; // Vector connecting the two bodies
    return r.normalize(); // Return normalized vector
}

vec body::angular_momentum(const body &b) const
{
    vec r = pos_ - b.pos_; // Vector connecting the two bodies
    return mass_*r.cross(vel_); // Return m r x v
}

std::ostream &operator<<(std::ostream &os, const body &b)
{
	b.output(os);
	return os;
}