#include <iostream> // Usual library header

/* --- Declaration of rational --- */

class rational {
    public:
        // Constructors
        rational();
        rational(int a, int b);
        // Responsibilities 
        void print() const;
        rational operator+(const rational& other_rational) const;
    private:
        int numerator; // The numerator
        int denominator; // The denominator
};

int main()
{
    rational A(13,727); // Declare and initialise a rational number
    rational B(231,983); // Declare and initialise a rational number
    // Display the numbers:
    A.print();
    B.print(); 
    // Declare and initialise a rational number by adding the first two together:
    rational C = A + B; 
    C.print();
    
    return EXIT_SUCCESS;
}

/* --- Implementation of rational --- */

// Default construction:
rational::rational()
{
    numerator = 1; // Set rational number to 1/1
    denominator = 1;
}

// Parameterised construction:
rational::rational(int a, int b)
{
    numerator = a; // Set rational number to a/b
    denominator = b;
}

// Access methods:
void rational::print() const
{
    std::cout << numerator << "/" << denominator << std::endl; // Print out number
}

rational rational::operator+(const rational& other_rational) const
{
    int a = numerator*other_rational.denominator + other_rational.numerator*denominator;
    int b = denominator*other_rational.denominator;
    rational sum(a,b);
    
    return sum;
}