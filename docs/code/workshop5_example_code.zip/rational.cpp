#include <iostream> // Usual library header

/* --- Declaration of rational --- */

class rational {
    public:
        // Constructors
        rational();
        rational(int a, int b);
        // Responsibilities 
        int GetNumerator() const;
        int GetDenominator() const;
    private:
        int numerator; // The numerator
        int denominator; // The denominator
};

int main()
{
    rational A; // Declare a rational number
    rational B(231,983); // Declare and initialise a rational number
    std::cout << "A = " << A.GetNumerator() << "/" << A.GetDenominator() << std::endl;
    std::cout << "B = " << B.GetNumerator() << "/" << B.GetDenominator() << std::endl;
    return EXIT_SUCCESS;
}

/* --- Implementation of rational --- */

// Default construction:
rational::rational()
{
    numerator = 1; // Set rational number to 1/1
    denominator = 1;
}

// Parameterised construction:
rational::rational(int a, int b)
{
    numerator = a; // Set rational number to a/b
    denominator = b;
}

// Access methods:
int rational::GetNumerator() const
{
    return numerator; 
}

int rational::GetDenominator() const
{
    return denominator;
}