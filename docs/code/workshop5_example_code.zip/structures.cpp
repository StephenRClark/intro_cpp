#include <iostream>
#include <cmath>

using std::cout, std::endl;

struct body {
    double mass; // Mass
    double pos[3]; // Position vector
    double vel[3]; // Velocity vector
    double radius; // Radius -- added this new member here
};

double density(body planet); // Declaration of the function

int main() 
{
    body earth; 
  
    earth.mass = 6.0e24; // Mass of earth [kg]
    earth.radius = 6.3781e6; // Radius of earth [m]
    
    double rho = density(earth); // Declare and call density function to define rho
    
    cout << "Density of Earth = " << rho << " kgm^-3" << endl;
    
    return EXIT_SUCCESS;
}

double density(body planet) // Definition of the function
{
    double volume = (4.0/3.0)*M_PI*pow(planet.radius,3);
    double rho = planet.mass/volume;
    return rho; 
}
