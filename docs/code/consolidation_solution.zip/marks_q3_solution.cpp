// Starter code for Question 3 of the online test
// g++ marks_q3_solution.cpp -o marks_q3
// ./marks_q3

#include <iostream>
// Need to add these headers:
#include <iomanip> 
#include <cmath>

void min_max(float marks[], int n, float& min, float& max); // Defines min and max as being pass by reference
void avg_std(float marks[], int n, float& avg, float& std); // Defines avg and std as being pass by reference

int main() 
{
  const int NumStudents = 36; // Number of students on the course 
  // List of exam marks for a 4th year Physics course:
  float marks[] = {65,68,58,67,60,77,53,53,56,42,60,69,70,69,83,62,57,63,90,54,62,58,77,57,59,54,61,51,38,72,71,46,27,48,52,71};
    
  std::cout << "Marks (" << NumStudents << "):" << std::endl;
  for (int i=0;i<NumStudents;i++) std::cout << marks[i] << std::endl; // Display the marks

  // Call the functions:
  float min, max, avg, std; // Declare variables to store results

  min_max(marks, NumStudents, min, max);
  std::cout << "Min mark: " << min << ", Max mark: " << max << std::endl;

  avg_std(marks, NumStudents, avg, std);
  std::cout << std::fixed << std::setprecision(1) << "Average mark: " << avg << ", Standard deviation: " << std << std::endl;

  return EXIT_SUCCESS;
}

// Implementation of functions:

// The min and max marks function:
void min_max(float marks[], int n, float& min, float& max) 
{ 
  min = marks[0];
  max = marks[0];
  for (int i=0;i<n;i++) 
  {
    if (marks[i] < min) min = marks[i];
    if (marks[i] > max) max = marks[i];
  }
}

// The average and standard deviation function:
void avg_std(float marks[], int n, float& avg, float& std) 
{
  avg = 0; // Compute average first 
  for (int i=0;i<n;i++) avg += marks[i];
  avg = avg/n;
  
  std = 0; // Then compute the standard deviation
  for (int i=0;i<n;i++) std += pow(marks[i] - avg,2);
  std = sqrt(std/n);
}
