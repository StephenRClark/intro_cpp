// Starter code for Question 1 of the online test
// g++ marks_q2_solution.cpp -o marks_q2
// ./marks_q2

#include <iostream>
// Need to add these headers:
#include <iomanip> 
#include <cmath>

int main() 
{
  const int NumStudents = 36; // Number of students on the course 
  // List of exam marks for a 4th year Physics course:
  float marks[] = {65,68,58,67,60,77,53,53,56,42,60,69,70,69,83,62,57,63,90,54,62,58,77,57,59,54,61,51,38,72,71,46,27,48,52,71};
    
  std::cout << "Marks (" << NumStudents << "):" << std::endl;
  for (int i=0;i<NumStudents;i++) std::cout << marks[i] << std::endl; // Display the marks

  // --- Solution from Q1 ---
  float min = marks[0];
  float max = marks[0];

  for (int i=0;i<NumStudents;i++) 
  {
    if (marks[i] < min) min = marks[i];
    if (marks[i] > max) max = marks[i];
  }
  std::cout << "Min mark: " << min << ", Max mark: " << max << std::endl;
  // ---

  float avg = 0;
  for (int i=0;i<NumStudents;i++) avg += marks[i];
  avg = avg/NumStudents;
  // Then compute the standard deviation:
  float std = 0;
  for (int i=0;i<NumStudents;i++) std += pow(marks[i] - avg,2);
  std = sqrt(std/NumStudents);
  std::cout << std::fixed << std::setprecision(1) << "Average mark: " << avg << ", Standard deviation: " << std << std::endl;

  return EXIT_SUCCESS;
}