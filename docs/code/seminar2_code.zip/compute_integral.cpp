// Seminar example 2: Wrapper for integration shared library
// g++ --std=c++11 integrate.so compute_integral.cpp -o compute_integral
// ./compute_integral
// You may need to change the LD_LIBRARY_PATH on your machine to ensure it can
// find integrate.so in run-time:
// export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:./
// This just tells the OS to look in the current directory for the shared library.

#include <iostream>
#include <iomanip>
#include <chrono>
#include "integrate.hpp"

int main() 
{
  double epsilon[] = {8.5, 0.0, 0.0,0.0, 8.5, 0.0, 0.0, 0.0, 8.5};
  double sigma = 0.7;
  double G_max = 20.0;  
  int N = 1000;
  double result;

  auto start = std::chrono::high_resolution_clock::now(); // Get starting timepoint                
  result = integrate(N, epsilon, sigma, G_max);
  auto stop = std::chrono::high_resolution_clock::now(); // Get ending timepoint
 
  // Get duration. Substart timepoints to get duration. To cast it to proper unit use duration cast method
  auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
 
  std::cout << std::setprecision(3);
  std::cout << "Completed in " << duration.count()/1e6 << " seconds" << std::endl;

  std::cout << "C++ final value after " << N << " iterations: " << std::setprecision(3) << result << std::endl; 

  return 0;
}