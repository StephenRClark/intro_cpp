// Seminar example 1: K-mer permutation construction in C/C++

// g++ --std=c++11 kmers_perm.cpp -o kmers_perm
// ./kmers_perm

#include <iostream>
#include <iomanip>
#include <string>
#include <chrono>

using namespace std;
using namespace std::chrono;

char convert(char c)
{
    if (c == 'A') return 'C';
    if (c == 'C') return 'G';
    if (c == 'G') return 'T';
    if (c == 'T') return 'A';
    return ' ';
}

int main()
{
    cout << "Start" << endl; 

    string opt = "ACGT";
    int len_str = 13;

    auto start = high_resolution_clock::now(); // Get starting timepoint

    string s = "";
    string s_last = "";

    for (unsigned int i=0; i<len_str; i++)
    {
        s += opt[0];
    }

    for (unsigned int i=0; i<len_str; i++)
    {
        s_last += opt.back();
    }

    int counter = 1;
    while (s != s_last)
    {   
        counter ++;
        // cout << s << endl; // You can uncomment this line to see all k-mers.  
        bool change_next = true;
        for (int i=0; i<len_str; i++)
        {
            if (change_next)
            {
                if (s[i] == opt.back())
                {
                    s[i] = convert(s[i]);
                    change_next = true;
                } else {
                    s[i] = convert(s[i]);
                    break;
                }
            }
        }
    }

    auto stop = high_resolution_clock::now(); // Get ending timepoint
 
    // Get duration. Substart timepoints to get duration. To cast it to proper unit use duration cast method
    auto duration = duration_cast<microseconds>(stop - start);
 
    cout << std::setprecision(3);
    cout << "Completed in " << duration.count()/1e6 << " seconds" << endl;

    cout << "Number of generated k-mers: " << counter << endl;
    cout << "Finish!" << endl; 
    return 0;
}
