from time import time
import numpy as np
import numba
 
""" set up variables """
def measure_time(function):
    def timed(*args, **kwargs):
        begin = time()
        result = function(*args, **kwargs)
        end = time()
 
        print('Completed in {:5.3f} seconds'.format(end - begin))
        return result
    return timed
 
epsilon = np.array([[8.5, 0.0, 0.0], 
                    [0.0, 8.5, 0.0], 
                    [0.0, 0.0, 8.5]])
 
sigma = 0.7
G_max = 20.0
N = 1000
                
kx_vector = np.linspace(-G_max, G_max, N, endpoint=False)
ky_vector = np.linspace(-G_max, G_max, N, endpoint=False)
kz_vector = np.linspace(-G_max, G_max, N, endpoint=False)
 
 
""" Python """
@numba.njit()
def function(k, epsilon, sigma, G_max):
    k_mod = np.dot(k, k)
    if k_mod < G_max**2:
        exponent = np.dot(np.dot(k, epsilon), k)
        return np.exp(-sigma**2 * exponent) / exponent
     
    return 0.0
 
@measure_time
@numba.njit()
def integrate_python():
    integral = 0
    for kx in kx_vector:
        for ky in ky_vector:
            for kz in kz_vector:
                if kx == 0 and ky == 0 and kz == 0:
                    pass
                else:
                    k = np.array([kx, ky, kz])
                    value = function(k, epsilon, sigma, G_max)
                    integral += value
     
    volume_element = (2 * G_max / N)**3
    integral *= volume_element
    integral /= 2 * np.pi**2
    return integral
 
value = integrate_python()
print('Python with Numba final value after {:d} iterations: {:7.4f}'.format(N, value))
 
# You may need to change the LD_LIBRARY_PATH on your machine to ensure it can
# find integrate.so in run-time.

""" C++ """
import ctypes
from numpy import ctypeslib as npct
 
array_1d_double = npct.ndpointer(dtype=np.double, ndim=1, flags='CONTIGUOUS')
 
c_lib_numpy = npct.load_library("integrate.so",".")
c_lib_numpy.integrate.restype = ctypes.c_double
c_lib_numpy.integrate.argtypes = [ctypes.c_int, array_1d_double, ctypes.c_double, ctypes.c_double]
 
@measure_time
def integrate_cpp():
    integral = c_lib_numpy.integrate(N, epsilon.flatten(), sigma, G_max)
    return integral
 
value = integrate_cpp()
print('Python using C++ final value after {:d} iterations: {:7.4f}'.format(N, value))