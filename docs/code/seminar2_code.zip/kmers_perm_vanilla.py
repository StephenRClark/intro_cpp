# kmer permuation construction in python:
from time import time
 
# Define a time meaduring function:
def measure_time(function):
    def timed(*args, **kwargs):
        begin = time()
        result = function(*args, **kwargs)
        end = time()
 
        print('Completed in {:5.1f} seconds'.format(end - begin))
        return result
    return timed

# Conversion function for nucleotides
def convert(c):
    if (c == 'A'): return 'C'
    if (c == 'C'): return 'G'
    if (c == 'G'): return 'T'
    if (c == 'T'): return 'A'

# k-mer construction function:
@measure_time

def construct_kmers(len_str,opt):
    
    s = ""
    s_last = ""
    
    for i in range(len_str):
        s += opt[0]

    for i in range(len_str):
        s_last += opt[-1]

    counter = 1
    while (s != s_last):
        counter += 1
        # print(s) # You can uncomment this line to see all k-mers.
        change_next = True
        for i in range(len_str):
            if (change_next):
                if (s[i] == opt[-1]):
                    s = s[:i] + convert(s[i]) + s[i+1:]
                    change_next = True
                else:
                    s = s[:i] + convert(s[i]) + s[i+1:]
                    break
    return counter 
    

# Main script
print("Start")

opt = "ACGT"
len_str = 13

counter = construct_kmers(len_str,opt)
                    
print("Number of generated k-mers: {}".format(counter))
print("Finish!")