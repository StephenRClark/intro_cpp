counter = 0
while (counter < 1000000000):
  counter+=1

print(counter)