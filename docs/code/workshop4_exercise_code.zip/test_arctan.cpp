// Starter code for Exercise 2
// g++ arctan.cpp test_arctan.cpp -o test_arctan
// ./test_arctan

#include <iostream>
#include <cmath>
#include "arctan.hpp"

int main()
{
    double value, test;
    double tol = 1e-8; // Built-in accuracy tolerance to pass test
    
    // Perform a sequence of tests on arctan() function:
    std::cout << "-------------------------------" << std::endl;
    std::cout << "TEST1 - CHECK arctan(1/sqrt(3)) = pi/6" << std::endl;
    value = arctan(1/sqrt(3)); // Compute value
    test = fabs(value - M_PI/6); // Check its difference to analytical result
    std::cout << "|arctan(1/sqrt(3)) - pi/6| = " << test << std::endl;
    if(test < tol) std::cout << "[PASSED]" << std::endl;
    else std::cout << "[FAILED]" << std::endl;

    std::cout << "-------------------------------" << std::endl;
    std::cout << "TEST 2 - CHECK arctan(1) = pi/4" << std::endl;
    value = arctan(1); // Compute value
    test = fabs(value - M_PI/4); // Check its difference to analytical result
    std::cout << "|arctan(1) - pi/4| = " << test << std::endl;
    if(test < tol) std::cout << "[PASSED]" << std::endl;
    else std::cout << "[FAILED]" << std::endl;

    std::cout << "-------------------------------" << std::endl;
    std::cout << "TEST 3 - CHECK arctan(2) = 1.1071..." << std::endl;
    value = arctan(2); // Compute value
    test = fabs(value - atan(2)); // Check its difference to analytical result
    std::cout << "|arctan(2) - atan(2)| = " << test << std::endl;
    if(test < tol) std::cout << "[PASSED]" << std::endl;
    else std::cout << "[FAILED]" << std::endl;

    return EXIT_SUCCESS; // Return 0 indicating successful execution
}