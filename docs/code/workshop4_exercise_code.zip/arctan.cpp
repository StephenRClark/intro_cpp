// Implementation file for arctan() function
#include <iostream>
#include <cmath>
#include "arctan.hpp"

double arctan(double x)
{
    // REPLACE THIS LINE:
    return x = atan(x); // CHEAT implementation using standard library
}

double arctan(int N, double x)
{
    // Implement the Taylor series expansion for |x| <= 1

    // REPLACE THIS LINE:
    return 0;
}
