#!/bin/bash

#SBATCH --account=PHYS033164
#SBATCH --job-name=fractal
#SBATCH --partition=teach_cpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --time=0:0:10
#SBATCH --mem=100M

echo 'Compute my first fractal'
hostname
./mandelbrot 1 20 20 1