#!/bin/bash

#SBATCH --account=PHYS033164
#SBATCH --job-name=fractal_array
#SBATCH --partition=teach_cpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --time=0:0:10
#SBATCH --mem=100M
#SBATCH --output=./output/slurm-%A_%a.out
#SBATCH --array=1-16

echo 'Fractal array job -' ${SLURM_ARRAY_TASK_ID}
hostname
./mandelbrot 4 200 200 ${SLURM_ARRAY_TASK_ID}
mv ./fractal_data_${SLURM_ARRAY_TASK_ID}.csv ./data