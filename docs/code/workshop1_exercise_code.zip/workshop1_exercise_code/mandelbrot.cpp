// C++ implementation for Mandelbrot set fractals

// To avoid warnings tell the compiler to use a recent standard of C++:
// g++ -std=c++17 mandelbrot.cpp -o mandelbrot
// ./mandelbrot 1 20 20 1

#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

using std::cout, std::endl;

// Function to compute if a point is inside the Mandelbrot set:
int mandelbrot(double cx, double cy, int D)
{
    double zx = 0.0, zy= 0.0; // Starting point is the origin.
    double Zx, Zy; // Intermediate complex number.
    int count = 0; // Iteration counter.

    // If the distance from the origin is greater than 2 
    // AND the maximum of iterations D is reached, then exit the loop:
    while ((zx*zx + zy*zy < 4) && (count < D)) {
        // Calculate Mandelbrot function Z = z*z + c, where z is a complex number:
        Zx = zx*zx - zy*zy + cx; // Real part of Z.
        Zy = 2*zx*zy + cy; // Imaginary part of Z.

        // Update z as Z and iterate:
        zx = Zx;
        zy = Zy;

        count++; // Increment the iteration counter
    }
    return count;
}

// USAGE:   mandelbrot N, P, D, n
// N = number of boxes in the complex plane as N x N
// P = points in each box as P x P
// D = depth of calculation as the maximum iteration count
// n = 1, 2, ..., N*N, the number of the box to be computed
// OUTPUT:  fractal_data_<n>.csv

int main(int argc, char** argv)
{ 
    double cx, cy; // Coordinates used in main loop.
    int count; // Counter used in main loop.

    // Checking if number of argument is equal to 4 or not.
    if (argc < 4 || argc > 5) {
        cout << "ERROR: need 4 input arguments - mandelbrot N P D n" << endl;
        return 0;
    }
  
    // Convert command line inputs from strings to integers:
    int N = atoi(argv[1]); 
    int P = atoi(argv[2]);
    int D = atoi(argv[3]);
    int n = atoi(argv[4]);

    // Fixed total box for computing fractal image is 3x3 with
    // bottom left corner at (-2,-1.5).
    double x0 = -2;
    double y0 = -1.5;
    double d = 3.0/(N*P-1); // Pixel size d x d.

    // Determine which box along the x and y axis the fractal is to be computed in:
    int nx = n % N;
    int ny = floor((n-1)/N);
    // Corresponding coordinates of the bottom left corner of the box:
    double left = d*P*nx + x0;
    double bottom = d*P*ny + y0;
  
    std::string filename = "fractal_data_"; // Fixed filename prefix.
    filename += std::to_string(n); // Append the box number to the data file.
    filename += ".csv"; // Save as a comma separated value text file.
    std::ofstream myfile (filename);
    if (myfile.is_open()) {
        // Scanning every point in the box:
	    for (int x=0; x<P; x++) {
		    for (int y=0; y<P; y++) {
                // Coordinate of constant c 
                cx = x*d + left; // Real part of c.
                cy = y*d + bottom; // Imaginary part of c.

                // Iterate z = z*z + c with starting point at the origin:
                count = mandelbrot(cx,cy,D);
                // Save data as a line in a comma separated text file:
                myfile << cx << "," << cy << "," << count << endl;
            }
        }
        myfile.close();
        cout << "Mandelbrot set computation complete" << endl;
    }
    else cout << "Unable to open file" << endl;

    return EXIT_SUCCESS;
}