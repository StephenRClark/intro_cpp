// C++ implementation for Mandelbrot set fractals

// To avoid warnings tell the compiler to use a recent standard of C++:
// g++ -std=c++17 mandelbrot.cpp -o mandelbrot
// ./mandelbrot 20 20 

#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

using std::cout, std::endl;

// Function to compute if a point is inside the Mandelbrot set:
int mandelbrot(double cx, double cy, int D)
{
    double zx = 0.0, zy= 0.0; // Starting point is the origin.
    double Zx, Zy; // Intermediate complex number.
    int count = 0; // Iteration counter.

    // If the distance from the origin is greater than 2 
    // AND the maximum of iterations D is reached, then exit the loop:
    while ((zx*zx + zy*zy < 4) && (count < D)) {
        // Calculate Mandelbrot function Z = z*z + c, where z is a complex number:
        Zx = zx*zx - zy*zy + cx; // Real part of Z.
        Zy = 2*zx*zy + cy; // Imaginary part of Z.

        // Update z as Z and iterate:
        zx = Zx;
        zy = Zy;

        count++; // Increment the iteration counter
    }
    return count;
}

// USAGE:   mandelbrot N, D
// N = number of point in the complex plane as N x N
// D = depth of calculation as the maximum iteration count
// OUTPUT:  fractal_data.csv

int main(int argc, char** argv)
{ 
    double cx, cy; // Coordinates used in main loop.
    int count; // Counter used in main loop.

    // Checking if number of argument is equal to 2 or not.
    if (argc < 2 || argc > 3) {
        cout << "ERROR: need 2 input arguments - mandelbrot N D" << endl;
        return 0;
    }
  
    // Convert command line inputs from strings to integers:
    int N = atoi(argv[1]); 
    int D = atoi(argv[2]);

    // Fixed total box for computing fractal image is NxN with
    // bottom left corner at (-2,-1.5).
    double left = -2;
    double bottom = -1.5;
    double d = 3.0/(N-1); // increment
  
    std::string filename = "fractal_data.csv"; // Fixed output filename.
    std::ofstream myfile (filename);
    if (myfile.is_open()) {
        // Scanning every point in the box:
	    for (int x=0; x<N; x++) {
		    for (int y=0; y<N; y++) {
                // Coordinate of constant c 
                cx = x*d + left; // Real part of c.
                cy = y*d + bottom; // Imaginary part of c.

                // Iterate z = z*z + c with starting point at the origin:
                count = mandelbrot(cx,cy,D);
                // Save data as a line in a comma separated text file:
                myfile << cx << "," << cy << "," << count << endl;
            }
        }
        myfile.close();
        cout << "Mandelbrot set computation complete" << endl;
    }
    else cout << "Unable to open file" << endl;

    return EXIT_SUCCESS;
}