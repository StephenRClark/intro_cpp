// Solution to Exercise 2
// g++ pascal.cpp -o pascal
// ./pascal

#include <iostream>
#include <iomanip>

int main() 
{
  static const int N = 25; // Define the size of the triangle - pick an odd number
  long long int pascal[N][2*N]; // Define 2D array
  
  // Make sure the array is filled with zeros initially:
  for(int i=0;i<N;i++) for(int j=0;j<2*N;j++) pascal[i][j] = 0; 
  pascal[0][N] = 1;
  pascal[1][N-1] = 1;
  pascal[1][N] = 0;
  pascal[1][N+1] = 1;

  // Loop over remaining rows and compute:
  for(int i=2;i<N;i++)
  {
    // Deal with each element along the row:
    for(int j=1;j<(2*N-1);j++)
    {
      pascal[i][j] = pascal[i-1][j-1] + pascal[i-1][j+1];      
    }
    // Handle the boundaries:
    pascal[i][0] = pascal[i-1][1];
    pascal[i][2*N-1] = pascal[i-1][2*N-2];
  }

  // Now display the answer with some nice formattting:
  for(int i=0;i<N;i++)
  {
    // Deal with each element along the row:
    for(int j=0;j<2*N;j++) 
    {
      if (pascal[i][j]) std::cout << std::setw(7) << pascal[i][j]; // Set the width to make display nice
      else std::cout << std::setw(7) << " ";
    }
     std::cout << std::endl;
  }

  // Try alternative display:
  for(int i=0;i<N;i++)
  {
    // Deal with each element along the row:
    for(int j=0;j<2*N;j++) 
    {
      if (pascal[i][j])
      {
        if (pascal[i][j]%2) std::cout << ".";
        else std::cout << "x";  
      } 
      else std::cout << " ";
    }
    std::cout << std::endl;
  }

  return EXIT_SUCCESS;
}