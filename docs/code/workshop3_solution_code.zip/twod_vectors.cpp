// Solution to Exercise 3
// g++ -std=c++17 twod_vectors.cpp -o twod_vectors
// ./twod_vectors

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <vector>

int main()
{
  int N; 
  std::cout << "Grid size N = ";
  std::cin >> N; // Request grid size from the user

  // Initialise a 2D vector to store values of x, y and f:
  std::vector<std::vector<double>> x(N, std::vector<double> (N, 0)); 
  std::vector<std::vector<double>> y(N, std::vector<double> (N, 0)); 
  std::vector<std::vector<double>> f(N, std::vector<double> (N, 0)); 

  // Evaluate over [-1,1] 2D domain using an N x N grid:  
  for(int i=0;i<N;i++)
  {
    for(int j=0;j<N;j++)
    { 
      // Lattice coordinates over domain [-1,1]:
      x[i][j] = (double) (2*i)/(N-1) - 1;
      y[i][j] = (double) (2*j)/(N-1) - 1;

      // Evaluate the function at (x,y).
      f[i][j] = x[i][j]*exp(-pow(2*x[i][j],2)-pow(2*y[i][j],2));
    }
  }

  // Now save the data as output:
  std::ofstream savefile ("func.csv"); // Open save file
  if (!savefile.is_open()) 
  {
    std::cout << "Unable to open file\n"; // Exit if save file has not opened
    return EXIT_FAILURE;
  }
  savefile << N << std::endl; // Make first line the header with N
  savefile << std::setprecision(16); // Set the precision of the output to that of a double
  for(int i=0;i<N;i++)
  {
      for(int j=0;j<N;j++)
      {
        savefile << x[i][j] << "," << y[i][j] << "," << f[i][j] << std::endl;
      }
  }
  savefile.close();
  std::cout << "File saved" << std::endl;

  return EXIT_SUCCESS; 
}