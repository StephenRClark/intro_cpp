// Solution to Exercise 1
// g++ digits.cpp -o digits
// ./digits

#include <iostream>

int main() 
{
  const int NumInts = 7;
  // Define arrays containing the large integer numbers:
  int A[7] = {86,327,529,198,672,534,147};
  int B[7] = {119,265,870,256,627,623,246};
  int C[7] = {193,987,321,943,199,692,978};
  int ApB[7]; // Will store A+B
  int ApC[7]; // Will store A+C
  int remApB = 0; // Remainder carried over from A+B
  int remApC = 0; // Remainder carried over from A+C
  int add; // Storage for intermediate results
  
  // Loop over the digit blocks:
  for(int i=0;i<NumInts;i++)
  {
    add = A[i] + B[i] + remApB;
    ApB[i] = add%1000; // Add the digits modulo 1000 and compute remainder
    if (add >= 1000) remApB = 1;
    else remApB = 0;

    add = A[i] + C[i] + remApC;
    ApC[i] = add%1000; // Add the digits modulo 1000 and compute remainder
    if (add >= 1000) remApC = 1;
    else remApC = 0;
  }

  // Now display the answer with some nice formattting:
  std::cout << "A + B = ";
  if (remApB) std::cout << remApB << ","; else std::cout << "  ";
  // Loop over the digit blocks backwards: 
  for(unsigned int i=NumInts-1;i>0;i--) std::cout << ApB[i] << ",";
  std::cout << ApB[0] << std::endl;

  std::cout << "A + C = ";
  if (remApC) std::cout << remApC << ","; else std::cout << "  ";
  // Loop over the digit blocks backwards: 
  for(int i=NumInts-1;i>0;i--) std::cout << ApC[i] << ",";
  std::cout << ApC[0] << std::endl;
  
  return EXIT_SUCCESS;
}