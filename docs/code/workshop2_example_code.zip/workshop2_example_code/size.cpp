#include <iostream>

int main() 
{
  std::cout << "short int " << sizeof(short int) << "\n";
  std::cout << "int " << sizeof(int) << "\n";
  std::cout << "long int " << sizeof(long int) << "\n";
  std::cout << "float " << sizeof(float) << "\n";
  std::cout << "double " << sizeof(double) << "\n";

  return EXIT_SUCCESS;
}