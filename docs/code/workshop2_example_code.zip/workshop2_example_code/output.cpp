// Example of standard output manipulation

#include <iostream> // Needed for cout, endl, fixed, scientific
#include <iomanip> // Needed for setprecision and setw

int main()
{
  double small = 3.1415926535897932384626; // More digits than double can handle!
  double large = 6.02e17; // Note we can initialise using scientific notation
  float whole = 2.000000000;

  std::cout << "Some values in (default) general format" << std::endl;
  std::cout << "small:  " << small << std::endl;
  std::cout << "large:  " << large << std::endl;
  std::cout << "whole:  " << whole << std::endl << std::endl;

  std::cout << std::scientific; // Switch format mode to scientific

  std::cout << "The values in scientific format" << std::endl;
  std::cout << "small:  " << small << std::endl;
  std::cout << "large:  " << large << std::endl;
  std::cout << "whole:  " << whole << std::endl << std::endl;

  std::cout << std::fixed; // Switch format mode to fixed

  std::cout << "The same values in fixed format" << std::endl;
  std::cout << "small:  " << small << std::endl;
  std::cout << "large:  " << large << std::endl;
  std::cout << "whole:  " << whole << std::endl << std::endl;
  
  std::cout << "Now change the precision" << std::endl;
  std::cout << std::setprecision(16); // More digits than double precision
  std::cout << "small:  " << small << std::endl;
  std::cout << std::setprecision(0); // No decimal digits
  std::cout << "large:  " << large << std::endl;
  std::cout << std::setprecision(2); // Set the width to flush to the right
  std::cout << "whole:  " << std::setw(18) << whole << std::endl << std::endl;
  
  return EXIT_SUCCESS;
}