// Example of a while-loop.

#include <iostream>

int main() 
{
  int i = 0; // Do initialiser
  int isq; 
  
  while (i<10) 
  {
    isq = i*i; // Compute i squared
    std::cout << "i=" << i << ", i^2=" << isq << "\n"; // Display output
    i++; // Do incrementer
  }

  return EXIT_SUCCESS;
}