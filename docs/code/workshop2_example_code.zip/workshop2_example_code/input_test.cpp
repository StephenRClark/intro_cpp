// Example of if-statement testing whether an input is correct.

#include <iostream>

int main() {
    int i; // Define a variable to store input 
    std::cout << "Please enter an integer value: "; 
    // Extract a value from the keyboard
    if (!(std::cin >> i)) {
        std::cerr << "That wasn't an integer." << std::endl; // Output to standard error
        return EXIT_FAILURE; // Return error code
    }
    std::cout << "The value you entered is " << i;
    std::cout << " and its double is " << i*2 << "." << std::endl;
    return EXIT_SUCCESS;
}