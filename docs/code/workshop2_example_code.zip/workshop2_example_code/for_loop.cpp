// Example of a for-loop.

#include <iostream>

int main() 
{
  int i, isq; 
  
  for (i=0; i<30; i=i+3) 
  {
    isq = i*i; // Compute i squared
    std::cout << "i=" << i << ", i^2=" << isq << "\n"; // Display output
  }

  return EXIT_SUCCESS;
}