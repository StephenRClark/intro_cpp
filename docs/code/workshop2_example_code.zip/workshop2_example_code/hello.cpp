#include <iostream>

int main()
{
    std::cout << "Hello world!\n"; // The main purpose of this program!
    return EXIT_SUCCESS; // Return 0 indicating successful execution
}