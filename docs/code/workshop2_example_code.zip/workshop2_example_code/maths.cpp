// Example of using maths function in C++.

#include <iostream>
#include <cmath>

int main()
{
    double x = 0.91211;
    double y, z;
    
    y = exp(-acos(x));
    z = cbrt(fabs(atan(x)));
    std::cout << "Answer = " << z <<  std::endl;
    
    return EXIT_SUCCESS;
}