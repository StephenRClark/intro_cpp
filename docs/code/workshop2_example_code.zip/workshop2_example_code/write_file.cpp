// Example of file output.

#include <iostream>
#include <fstream>

int main() 
{
  double pi = 3.141592;
  std::ofstream myfile; // Declare a file stream object
  myfile.open ("example.txt"); // Open a file
  myfile << "The value of pi = " << pi << "\n"; // Insert data to this file
  std::cout << "Have written to file example.txt" << std::endl;
  myfile.close(); // Close the file
  return EXIT_SUCCESS;
}