// Example of casting variables.

#include <iostream>

int main() 
{
  int i,j;
  float x, y, z;
  i=10;
  j=3;
  x=i/j; // Compute 10/3 and store in float x
  std::cout << "x=" << x << "\n";
  y = 2.71828; // Define float y
  z = y/j; // Compute y/3 and store in float z
  std::cout << "z=" << z << "\n";
  return EXIT_SUCCESS;
}