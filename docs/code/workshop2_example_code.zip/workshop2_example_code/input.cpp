// Example of user console input.

#include <iostream>

int main()
{
  int i; // Define a variable to store input
  std::cout << "Please enter an integer value: ";
  std::cin >> i; // Extract a value from the keyboard
  std::cout << "The value you entered is " << i;
  std::cout << " and its double is " << i*2 << ".\n";
  return EXIT_SUCCESS;
}