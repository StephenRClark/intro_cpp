// Example of variable scope inside blocks {}.

#include <iostream>

int main () 
{
  for (int i=0; i<30; i=i+3) // Declare i inside for loop
  {
    int isq = i*i; // Declare and compute i squared
    std::cout << "i=" << i << ", i^2=" << isq << "\n"; // Display output
  }
  return EXIT_SUCCESS;
}