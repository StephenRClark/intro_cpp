#ifndef BODY_H
#define BODY_H

#include <iostream>

// body class definition:
class body
{
public:
	// Initialize with all parameters zero
	body();
	// Initialize with another body
    body(const body &b);
    // Initialize explicitly m, pos, vec
	body(double m, vec pos, vec vel);
	// Set to m, pos, vec
	void set(double m, vec pos, vec vel);
	// Initialize explicitly m, x, y, z, vx, vy, vz
	body(double m, double x, double y, double z, double vx, double vy, double vz);
	// Set to m, x, y, z, vx, vy, vz
	void set(double m, double x, double y, double z, double vx, double vy, double vz);

	// Assign to the values of another body
	body &operator=(const body &b);
	
	// Formatted output function for displaying the properties of this body
	void output(std::ostream &os) const;

	// Distance between this body and another b
	double distance(const body &b) const;

    // A normalised vector pointing between this body and another b
	vec direction(const body &b) const;

    // Compute the angular momentum of the body relative to the location of another body b
	vec angular_momentum(const body &b) const;

private:
	double mass_;
	vec pos_;
	vec vel_;
};

std::ostream &operator<<(std::ostream &os, const body &b); // Overload insertion operator for displaying a body

#endif  // BODY_H