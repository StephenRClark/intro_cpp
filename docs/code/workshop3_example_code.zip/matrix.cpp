// Example
// g++ matrix.cpp -o matrix
// ./matrix

#include <iostream>

int main() 
{
  static const int n = 2; // Define square matrix size
  float A[n][n] = {{2,0},{3,1}}; // Declare and initialise
  float B[n][n] = {{1,1},{-2,0}}; 
  float C[n][n];

  for(int i=0; i<n; i++) 
  {
    for(int j=0; j<n; j++) 
    {
      C[i][j] = 0.0; // Initialise C to erase junk
      for(int k=0; k<n; k++) 
      {
        C[i][j] += A[i][k]*B[k][j];
      }
      std::cout << C[i][j] << " "; // Display result
    }
    std::cout << std::endl;
  }
  
  return EXIT_SUCCESS;
}