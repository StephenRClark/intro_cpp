// Example
// g++ user_vector.cpp -o user_vector
// ./user_vector

#include <iostream>
#include <vector> // Add this header to use vectors

int main() 
{
  int num = 0; // Will store number of elements
  std::cout << "Number of elements num = ";
  std::cin >> num; 
  std::cout << std::endl;
  
  std::vector<int> squares(num);  // Creates a vector with num elements.
  
  for (int i = 0; i < num; i++)
  {
    squares[i] = i * i;  // Vector element indexing.
    std::cout << "The square of " << i << " is " << squares[i] << std::endl;
  }
  
  return EXIT_SUCCESS;
}