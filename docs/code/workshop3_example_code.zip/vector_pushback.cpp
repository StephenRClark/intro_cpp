// Example
// g++ vector_pushback.cpp -o vector_pushback
// ./vector_pushback

#include <iostream>
#include <vector> // Add this header to use vectors

int main() 
{
  int num = 0; // Will store number of elements
  std::cout << "Number of elements num = ";
  std::cin >> num; 
  std::cout << std::endl;
  
  std::vector<int> squares;  // Creates empty vector
  
  for (int i = 0; i < num; i++)
  {
    squares.push_back(i*i);  // Append to the end
    std::cout << "The square of " << i << " is " << squares[i] << std::endl;
  }
  
  return EXIT_SUCCESS;
}

  