// Example
// g++ -std=c++17 2d_vector.cpp -o 2d_vector
// ./2d_vector

#include <iostream>
#include <vector> // Add this header to use vectors

int main() 
{
  // Define explicitly a 3x3 matrix A
  std::vector<std::vector<float>> A = { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} }; 
  int Arows = A.size(); // Number of rows in A
  int Acols = A[0].size();  // Number of columns in A
  
  // Define explicitly a 3x2 matrix B
  std::vector<std::vector<float>> B = { {4, 1}, {5, 2}, {1, 0} }; 
  int Brows = B.size(); // Number of rows in B - must be equal to Acols
  int Bcols = B[0].size(); // Number of columns in B
  
  // Define a 3x2 matrix of zeros C
  std::vector<std::vector<float>> C(Arows, std::vector<float> (Bcols, 0)); 

  for(int i=0; i<Arows; i++) 
  {
    for(int j=0; j<Bcols; j++) 
    {
      for(int k=0; k<Acols; k++) 
      {
        C[i][j] += A[i][k]*B[k][j];
      }
      std::cout << C[i][j] << " "; // Display result
    }
    std::cout << std::endl;
  }
  
  return EXIT_SUCCESS;
}