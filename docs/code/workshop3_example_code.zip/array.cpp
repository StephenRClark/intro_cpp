// Example
// g++ array.cpp -o array
// ./array

#include <iostream> 

int main()
{
    static const int num = 22; // The number of integers
    static const int dim = 3; // The dimensions of vectors

    int A[num]; // Define an array of num integers
    float u[dim] = {1.0, 2.0, 3.0}; // Initialised so don't technically need to use dim
    float v[dim] = {2.0, 4.0, 3.0};
    float result = 0.0;
 
    // Display values of the arrays
    for(int i=0; i<num; i++) std::cout << A[i] << std::endl;
    for(int i=0; i<dim; i++) std::cout << u[i] << " " << v[i] << std::endl;

    for (int i=0; i<dim; i++) result = result + u[i]*v[i]; 
    std::cout << "Scalar product is " << result << std::endl;

    return EXIT_SUCCESS; 
}