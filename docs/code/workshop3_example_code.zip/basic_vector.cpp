// Example
// g++ basic_vector.cpp -o basic_vector
// ./basic_vector

#include <iostream>
#include <vector> // Add this header to use vectors

int main() 
{
  static const int num = 10; // Define number of elements 
  std::vector<int> squares(num);  // Creates a vector with num elements.
  
  for (int i = 0; i < num; i++)
  {
    squares[i] = i * i;  // Vector element indexing.
    std::cout << "The square of " << i << " is " << squares[i] << std::endl;
  }
  
  return EXIT_SUCCESS;
}