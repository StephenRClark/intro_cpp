import csv
import numpy as np
import matplotlib.pyplot as py

N = 4 #Number of boxes is NxN
P = 200 #Number of points in each box

#Coordinate of bottom left corner of the region of complex plane:
x0 = -2 
y0 = -1.5
S = 3 #Size of the full box in the complex plane.

z = np.zeros([N*P,N*P]) #Initialise full storage
fileprefix = "./data/fractal_data_"
filesuffix = ".csv"

#Loop over all the data files:
for n in range(N**2):
    
  #Read in the .csv data file: 
  filename = fileprefix + str(n+1) + filesuffix
  file = open(filename)
  csvreader = csv.reader(file)
  rows = []
  for row in csvreader:
    rows.append(row)
  file.close()

  #Extract the data:
  data = np.zeros(len(rows))
  for i in range(len(rows)):
    data[i] = rows[i][2]
  
  
  #Indices for inserting data:
  nx = (n+1) % N 
  ny = int(np.floor(n/N)) 
  
  #Insert into the full array:
  z[(nx*P):((nx+1)*P),(ny*P):((ny+1)*P)] = np.reshape(data,[P,P])
  
z = np.transpose(z) #Flip the matrix around.   
# Plot 2D image:  
py.pcolormesh(np.linspace(x0,x0+S,N*P),np.linspace(y0,y0+S,N*P),np.log10(z))