// Solution to Exercise 2
// g++ trapezium.cpp -o trapezium
// ./trapezium

#include <iostream>
#include <iomanip>
#include <cmath> // Include C maths library

int main() 
{
  int N, i;
  float h, fint, fx, x, err, err_bnd;
  
  std::cout << "Number of steps N = ";
  std::cin >> N; // Obtain the input
  std::cout << std::setprecision(6); // Set to 5 d.p. precision

  fint = 0;
  h = (float) 1/(N-1); // Step-size
  for(i=0;i<N;i++)
  {
    x = (float) i*h; // Current x sample
    fx = (5*pow(x,4) + 4*pow(x,3) + 3*pow(x,2) + 2*x + 1); // Evaluate f(x)
    std::cout << "f(x[" << i+1 << "]) = " << fx << "\n";
    if (i==0 || i==(N-1)){
      fint += 0.5*fx*h; // Deal with the boundary points, note 0.5* NOT (1/2)*
    }
    else{
      fint += fx*h; // Deal with the bulk points
    }
  }
  std::cout << "Integral = " << fint << " in " << N << " steps\n";
  return EXIT_SUCCESS;
}