// Solution to Exercise 3
// g++ newton.cpp -o newton
// ./newton

#include <iostream>
#include <iomanip>
#include <cmath> // Include C maths library

int main()
{
	 double x0, x1, f0, f1, fd0;
	 int step = 1;
     double conv = 1e-13; // Convergence criteria required to get 12 d.p. solution

     std::cout << std::setprecision(12) << std::fixed; // Fix the output format

	 std::cout << "Enter initial guess: "; // Get an initial guess the from the user
	 std::cin >> x0;

	 std::cout << std::endl << "*********************" << std::endl;
	 std::cout << "Newton Raphson Method" << std::endl;
	 std::cout << "*********************" << std::endl;

	 do
	 {
		  f0 = cos(x0) - pow(x0,3); // Function f(x0)
          fd0 = -sin(x0) - 3*pow(x0,2); // Derivative f'(x0)

          // Technically we should check that fd0 is not zero to avoid an overflow error

		  x1 = x0 - f0/fd0; // Newton-Raphson interation step

          f1 = cos(x1) - pow(x1,3); // Function f(x1)

		  std::cout << "Iteration-" << step << ":\t x = "<< std::setw(10) << x1 << " and f(x) = " << std::setw(10) << f1 << std::endl;
		  
          x0 = x1;
		  step++;

          // We could also have included a maximum iteration number test to make sure the while loop does exit

	 } while (fabs(f1)>conv);

	 std::cout << std::endl << "Root is: " << x1;
	 return EXIT_SUCCESS;
}