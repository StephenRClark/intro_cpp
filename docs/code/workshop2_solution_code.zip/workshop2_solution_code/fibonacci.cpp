// Solution to Exercise 1
// g++ fibonacci.cpp -o fibonacci
// ./fibonacci

#include <iostream>
#include <iomanip>
#include <cmath> // Include C maths library

int main() 
{
  int N, i, n, n_prev, n_curr;
  double golden = (1 + sqrt(5))/2; // Declare and define the Golden ratio
  
  std::cout << "Number of terms N = ";
  std::cin >> N; // Obtain the input
  std::cout << std::setprecision(15); // Set a high precision for display of doubles
  
  // Initialise the sequence:
  n_prev = 1;
  n_curr = 1;
  std::cout << "1, 1 (1)";
  for (i=0;i<(N-2);i++)
  {
    n = n_curr + n_prev;
    double ratio = (double) n/n_curr;
    std::cout << ", " << n << " (" << ratio << ")"; // Display sequence with (ratio)
    n_prev = n_curr;
    n_curr = n;
  }
  std::cout << "\n";
  std::cout << "Golden ratio = " << golden << "\n";

  return EXIT_SUCCESS;
}