// Solution to Exercise 3
// g++ -std=c++17 twod_vectors.cpp -o twod_vectors
// ./twod_vectors

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <vector>

int main()
{
  // -----------------------------------------
  // Write your code here -> 

  // - Ask user for N
  // - Declare 3 2d vectors for x, y and f
  // - Populate x, y and f with values

  // -----------------------------------------
  // Now save the data as output:
  std::ofstream savefile ("func.csv"); // Open save file
  if (!savefile.is_open()) 
  {
    std::cout << "Unable to open file\n"; // Exit if save file has not opened
    return EXIT_FAILURE;
  }
  savefile << N << std::endl; // Make first line the header with N
  savefile << std::setprecision(16); // Set the precision of the output to that of a double
  for(int i=0;i<N;i++)
  {
      for(int j=0;j<N;j++)
      {
        savefile << x[i][j] << "," << y[i][j] << "," << f[i][j] << std::endl;
      }
  }
  savefile.close();
  std::cout << "File saved" << std::endl;

  return EXIT_SUCCESS; 
}