// Starter code for Question 3 of the online test
// g++ marks_q3.cpp -o marks_q3
// ./marks_q3

#include <iostream>

void min_max(float marks[], int n, float& min, float& max); // Defines min and max as being pass by reference
void avg_std(float marks[], int n, float& avg, float& std); // Defines avg and std as being pass by reference

int main() 
{
  const int NumStudents = 36; // Number of students on the course 
  // List of exam marks for a 4th year Physics course:
  float marks[] = {65,68,58,67,60,77,53,53,56,42,60,69,70,69,83,62,57,63,90,54,62,58,77,57,59,54,61,51,38,72,71,46,27,48,52,71};
    
  std::cout << "Marks (" << NumStudents << "):" << std::endl;
  for (int i=0;i<NumStudents;i++) std::cout << marks[i] << std::endl; // Display the marks

  // --- YOUR CODE HERE ---
  // Call min_max() and avg_std() and display the results.

  return EXIT_SUCCESS;
}

// --- YOUR CODE HERE ---
// Write the implementation of min_max() and avg_std() here: