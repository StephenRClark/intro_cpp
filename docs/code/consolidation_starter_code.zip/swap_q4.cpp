// Starter code for Question 4 of the online test
// g++ swap_q4.cpp -o swap_q4
// ./swap_q4

#include <iostream>

void swapf(float& a, float& b); // Declare the swap function

int main() 
{
  const int n = 3; // Matrix dimension n x n
  float matrix[3][3] = { {1.0, 2.0, 3.0},
                         {4.0, 5.0, 6.0},
                         {7.0, 8.0, 9.0} };

  std::cout << "Before swap\n";
  for (int i=0;i<n;i++)
  {
    for (int j=0;j<n;j++) std::cout << matrix[i][j] << " ";
    std::cout << std::endl;
  }

  // Perform matrix transposition:
  for (int i=0;i<n;i++)
    for (int j=0;j<i;j++) // Only loop over off-diagonal elements
      swapf(matrix[i][j], matrix[j][i]);

  std::cout << "After swap\n";
  for (int i=0;i<n;i++)
  {
    for (int j=0;j<n;j++) std::cout << matrix[i][j] << " ";
    std::cout << std::endl;
  }

  return EXIT_SUCCESS;
}

void swapf(float& a, float& b) 
{
  // --- YOUR CODE HERE ---
}