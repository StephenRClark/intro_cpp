import csv
import numpy as np
import matplotlib.pyplot as plt

N = 10000 #Sample size for each average

savefile = "./random_data.txt"

#Read in the .csv data file: 
file = open(savefile)
csvreader = csv.reader(file)
rows = []
for row in csvreader:
  rows.append(row)
file.close()

#Initialise storage for data
data = np.zeros(N)

#Main field variables:
for j in range(N):
  data[j] = rows[j][0]

#Create a histogram of the data:
fig, ax = plt.subplots()
[n,bins,patches] = plt.hist(data, 50, density=True, facecolor='b', alpha=0.75)
plt.xlabel('prob')
plt.ylabel('value')
plt.title('Histogram of C++ random number generator data')
plt.xlim(-0.1, 0.1)
plt.grid(True)

#Add Uniform distribution:
y = 0.5*np.ones(51)
plt.plot(bins, y, '--')
plt.show()