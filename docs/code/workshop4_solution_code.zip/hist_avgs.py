import csv
import numpy as np
import matplotlib.pyplot as plt

L = 10000 #Data size to read
N = 1000 #Sample size for each average

savefile = "./random_avgs.txt"

#Read in the .csv data file: 
file = open(savefile)
csvreader = csv.reader(file)
rows = []
for row in csvreader:
  rows.append(row)
file.close()

#Initialise storage for data
data = np.zeros(L)

#Main field variables:
for j in range(L):
  data[j] = rows[j][0]

#Create a histogram of the data:
fig, ax = plt.subplots()
[n,bins,patches] = plt.hist(data, 50, density=True, facecolor='b', alpha=0.75)
plt.xlabel('prob')
plt.ylabel('value')
plt.title('Histogram of sample averages')
plt.grid(True)

#Add Gaussian distribution:
mu = 0  # mean of distribution
sigma = 1/np.sqrt(3*N)  # standard deviation of distribution
y = ((1 / (np.sqrt(2 * np.pi) * sigma)) *
     np.exp(-0.5 * (1 / sigma * (bins - mu))**2))
plt.plot(bins, y, '--')
plt.show()