// Header file for arctan() function

#ifndef _ARCTAN_H // Header guard
#define _ARCTAN_H

double arctan(double x); // Main function call
double arctan(int N, double x); // Overloaded function call for Taylor expansion

#endif