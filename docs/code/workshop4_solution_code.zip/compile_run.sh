#!/bin/bash
# You may need to use the command: 
#   chmod 755 compile_run.sh
# to allow this script to be executed

# Delete previous executable:
rm -f test_arctan

# Define standard flags for C++ compilation:
CXXFLAGS="-std=c++11 -pedantic -O3 -Wall"

# Compile the source files into object files:
g++ ${CXXFLAGS} -c arctan.cpp -o arctan.o
g++ ${CXXFLAGS} -c test_arctan.cpp -o test_arctan.o

# Perform linking to generate executable:
g++ arctan.o test_arctan.o -o test_arctan

# Tidy up by removing object files:
rm -f arctan.o test_arctan.o
echo "Compiled test_arctan code and now running ..."

# Run the compiled code:
./test_arctan