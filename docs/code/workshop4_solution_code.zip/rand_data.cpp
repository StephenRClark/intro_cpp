#include <iostream>
#include <fstream>
#include <random>
#include <chrono>

int main()
{
    static const int N = 10000; // Some fixed number of random numbers needed

    // Initialise the random number generator:
    std::default_random_engine generator;
    std::uniform_real_distribution<double> distribution(-1.0,1.0);
    
    // Initialise a clock object
    typedef std::chrono::high_resolution_clock myclock;
    myclock::time_point beginning = myclock::now();

     // Obtain a seed from the timer and apply it
    myclock::duration d = myclock::now() - beginning;
    unsigned seed = d.count();
    generator.seed(seed); // Apply the seed

    std::ofstream data_file; // Declare a file stream object
    data_file.open ("random_data.txt"); // Open a file
    // Just write out the random number data directly to the file:
    for(unsigned int i = 0; i < N; i++) data_file << distribution(generator) << std::endl; 
    data_file.close(); // Close the file
    std::cout << "Random data saved" << std::endl;
    
    return EXIT_SUCCESS;
}    