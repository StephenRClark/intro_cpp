// Implementation file for arctan() function
#include <iostream>
#include <cmath>
#include "arctan.hpp"

double arctan(double x)
{
    static const int N = 10; // Number of terms in Taylor series
    // Need to use N = 100000000 for 1e-8 tolerance to pass test 2!
    double result = 0.0;

    if(fabs(x)>1)
    {
        // Deal with x outside [-1,1]:
        if(x>0) result = M_PI/2 - arctan(N,1/x); // x > 0
        else result = -M_PI/2 - arctan(N,1/x); // x < 0
        return result;
    } 
    else return arctan(N,x); // Return Taylor series result
}

double arctan(int N, double x)
{
    // Implement the Taylor series expansion for |x| <= 1
    double series = 0.0;

    for(unsigned int n=0; n<=N; n++)
    {
        // Compute term and remember to cast the coefficient involving integer n:
        series += pow(-1,n)*pow(x,2*n+1)*((double) 1/(2*n+1));
    } 
    return series;
}
