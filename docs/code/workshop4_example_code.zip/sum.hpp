/* --- sum.hpp --- */
#ifndef _SUM_H // Header guard
#define _SUM_H
double sum(double a, double b); // Function to return the sum of the two doubles
#endif