// Example of swapping two integers using pass-by-reference.

#include <iostream>

void swap_integers(int& a, int& b); // Declaration of the function

int main() 
{
    int x = 67; // Declare and initialise two integers
    int y = 24;
    
    std::cout << "x = " << x << " and y = " << y << "\n"; // Display variables
    swap_integers(x, y); // Swap the values of these variables by passing variables themselves
    std::cout << "x = " << x << " and y = " << y << "\n";  // Display them again
    return EXIT_SUCCESS;
}

void swap_integers(int& a, int& b)  // Definition of the function
{ 
    int local_var; // A local variable is needed to perform a swap
    local_var = a; // No de-referencing needed.
    a = b; 
    b = local_var;
}