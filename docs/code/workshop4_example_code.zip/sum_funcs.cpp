// Example of overloading a function.

#include <iostream>

int sum(int a, int b); // Declared with two int arguments
double sum(double c, double d); // Declared with two double arguments 

// Note that it is ok to declare the function twice, even using different argument names
// (as long as the type are correct).
// Indeed, you don't have to specify the argument names.
double sum(double, double);

int main()
{
    std::cout << sum(10, 20) << std::endl;
    std::cout << sum(3.14159, 2.71828) << std::endl;
    return EXIT_SUCCESS;
}

// Definitions must use the same types as the declaration, and must provide argument 
// names since they are referenced in the body of the function. Unlike the type, 
// names don't have to match those used in the declarations (although it's good 
// practice to keep them consistent when names are used.)

// Defined with two int arguments
int sum(int c, int d)
{
    std::cout << "Sum of two ints is: ";
    return c + d;
}

// Defined with two double arguments
double sum(double a, double b)
{
    std::cout << "Sum of two doubles is: ";
    return a + b;
}