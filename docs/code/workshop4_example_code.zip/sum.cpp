/* --- sum.cpp --- */
#include "sum.hpp" // Our new header

double sum(double a, double b)
{
    return a + b;
}  