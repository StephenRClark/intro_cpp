/* --- main.cpp --- */
// Compile:
// g++ main.cpp sum.cpp -o sum_example
// Run:
// ./sum_example

#include <iostream> // Usual library header
#include "sum.hpp" // Our new header

int main()
{
    std::cout << sum(10,20) << std::endl;
    return EXIT_SUCCESS;
}