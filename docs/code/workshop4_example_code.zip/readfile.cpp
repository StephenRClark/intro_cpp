// Example of reading data from a file.
// Make sure the file input.txt is in the same directory.

#include <iostream>
#include <fstream>
#include <string>

int main()
{
    std::string line; // Declare a string used to store each line
    double number; // Double to store number

    // Declare and initialise an input file stream object
    std::ifstream data_file("input.txt"); 

    while (getline(data_file, line)) // Read the file line by line
    {
        number = std::stod(line); // Convert line into a number
        std::cout << number << std::endl; // Output number to console
    }

    // Close the file
    data_file.close();
    return 0;
}    
