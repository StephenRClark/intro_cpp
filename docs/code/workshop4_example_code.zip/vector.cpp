// Example of vector pass-by-reference.
// This example requires a modern C++ compiler supporting c++11 extensions:
// Compile:
// g++ -std=c++11 vector.cpp -o vector
// Run:
// ./vector

#include <iostream>
#include <vector>
#include <cmath>

// Declaration functions:
double magnitude (std::vector<double> inputVector);  // Vector passed by value
double normalize (std::vector<double>& inputVector); // Vector passed by reference

int main() 
{
    std::vector<double> myVector{-0.82,1.23,0.77,-13.21}; // Declare and initialise components of a vector
    
    double mag = normalize(myVector); // Normalize vector and returns original magnitude
    std::cout << "|myVector| = " << mag << std::endl;  // Display the magnitude of original vector
    mag = magnitude(myVector); // Evaluate the magnitude again
    std::cout << "|normalize(myVector)| = " << mag << std::endl;  // Display the magnitude of the normalized vector
    return EXIT_SUCCESS;
}

// Definition of functions:
double magnitude(std::vector<double> inputVector)  
{ 
    double result = 0.0;
    for (int i=0; i<inputVector.size(); i++) 
    {
        result = result + inputVector[i] * inputVector[i];
    }
    return sqrt(result);
}

double normalize(std::vector<double>& inputVector) 
{ 
    double mag = magnitude(inputVector); 
    for (int i=0; i<inputVector.size(); i++) 
    {
        inputVector[i]  = inputVector[i]/mag; // Overwrite the vector components
    }
    return mag; // Return the original magnitude
}