// Example of function declarations and scope.

#include <iostream>

double square(double x); // Declaration of the function

int main() 
{
    double x, xsq;
    
    std::cout << "Enter a value:" << std::endl;
    std::cin >> x; // Read in a value
    xsq = square(x); // Square its value using our function
    std::cout << x << " squared is " << xsq << "\n"; // Display answer
    
    return EXIT_SUCCESS;
}

double square(double z) // Definition of the function
{
    double y = z * z; // Implement using a local variable
    z = 2*y; // Now modify the input variable
    return y; 
}