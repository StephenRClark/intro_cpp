// Example of generating random numbers.

#include <iostream>
#include <random>
#include <chrono>

int main()
{
    static const int N = 10; // Some fixed number of random numbers needed
    double nums[N]; // Define an array to store the numbers
    double avg = 0.0; // Will store the average of the numbers generated

    // Initialise the random number generator:
    std::default_random_engine generator;
    std::uniform_real_distribution<double> distribution(-1.0,1.0);
    
    // Initialise a clock object
    typedef std::chrono::high_resolution_clock myclock;
    myclock::time_point beginning = myclock::now();

    // Obtain a seed from the timer and apply it
    myclock::duration d = myclock::now() - beginning;
    unsigned seed = d.count();
    generator.seed(seed); // Apply the seed

    for(int i = 0; i < N; i++)
    {
        nums[i] = distribution(generator); // Request a random number
        avg += nums[i];   
        std::cout << "nums[" << i << "]  = " << nums[i] << "\n";
    }
    avg /= N;
    std::cout << "avg = " << avg << "\n";
    
    return EXIT_SUCCESS;
}    